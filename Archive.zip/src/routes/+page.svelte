<script>
    import { labs } from '$lib/stores.js';
    import { PlusCircle } from 'lucide-svelte'; // <-- เพิ่มบรรทัดนี้

    let labName = '';
    let labDifficulty = '';
    let labOs = '';

    function addLab() {
        if (!labName.trim()) return;
        labs.update(currentLabs => [
            {
                id: Date.now(),
                name: labName.trim(),
                difficulty: labDifficulty.trim(),
                os: labOs.trim(),
                completed: false,
                completedAt: null
            },
            ...currentLabs
        ]);
        labName = ''; labDifficulty = ''; labOs = '';
    }

    function toggleLabStatus(id) {
        labs.update(currentLabs => currentLabs.map(lab => {
            if (lab.id === id) {
                const isCompleted = !lab.completed;
                return { ...lab, completed: isCompleted, completedAt: isCompleted ? new Date().toISOString() : null };
            }
            return lab;
        }));
    }

    function deleteLab(id) {
        if (confirm('Are you sure?')) {
            labs.update(currentLabs => currentLabs.filter(lab => lab.id !== id));
        }
    }
</script>

<svelte:head>
    <title>Home - Lab Tracker</title>
</svelte:head>

<section class="bg-white p-6 rounded-xl shadow-sm border border-slate-100 mb-8">
    <h2 class="text-xl font-bold mb-4">Add New Lab</h2>
    <form on:submit|preventDefault={addLab} class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
        <div class="md:col-span-2">
            <label for="lab-name" class="block text-sm font-medium text-slate-600 mb-1">Lab Name</label>
            <input id="lab-name" type="text" placeholder="e.g., Lame" required bind:value={labName} class="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-400 focus:border-emerald-400 transition">
        </div>
        <div>
            <label for="lab-difficulty" class="block text-sm font-medium text-slate-600 mb-1">Difficulty</label>
            <input id="lab-difficulty" type="text" placeholder="e.g., Easy" bind:value={labDifficulty} class="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-400 focus:border-emerald-400 transition">
        </div>
        <button type="submit" class="w-full bg-emerald-500 text-white font-bold p-2 rounded-md hover:bg-emerald-600 transition-colors">Add Lab</button>
    </form>
</section>

<section class="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
    <h2 class="text-xl font-bold mb-4">Your Labs ({$labs.length})</h2>
    <div>
        {#if $labs.length === 0}
            <p class="text-center text-slate-500 py-8">No labs yet. Add one above!</p>
        {:else}
            {#each $labs as lab (lab.id)}
                <div class="flex items-center p-4 border-b border-slate-100 last:border-b-0 group">
                    <input type="checkbox" checked={lab.completed} on:change={() => toggleLabStatus(lab.id)} class="h-5 w-5 rounded border-slate-300 text-emerald-500 focus:ring-emerald-500 cursor-pointer">
                    <div class="ml-4 flex-grow">
                        <p class="font-semibold text-slate-800" class:line-through={lab.completed} class:opacity-50={lab.completed}>{lab.name}</p>
                        <p class="text-sm text-slate-500">
                            {lab.difficulty || 'N/A'} ・ {lab.os || 'N/A'}
                            {#if lab.completedAt}
                                <span class="italic ml-2">- Completed: {new Date(lab.completedAt).toLocaleDateString('en-GB')}</span>
                            {/if}
                        </p>
                    </div>
                    <button on:click={() => deleteLab(lab.id)} title="Delete Lab" class="text-slate-400 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100 ml-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                    </button>
                </div>
            {/each}
        {/if}
    </div>
</section>