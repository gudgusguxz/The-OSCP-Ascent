<script>
  import "../app.css";
  import { Home, BarChart3 } from 'lucide-svelte';
</script>

<div class="bg-slate-50 min-h-screen text-slate-800">
  <div class="container mx-auto p-4 md:p-8">
    <header class="flex flex-col sm:flex-row justify-between items-center pb-4 border-b border-slate-200 mb-8">
      <h1 class="text-2xl font-bold text-slate-900 mb-4 sm:mb-0">
        <a href="/">🚀 Lab Tracker Pro</a>
      </h1>
      <nav class="flex items-center gap-4">
        <a href="/" class="text-slate-500 font-semibold hover:text-emerald-500 transition-colors">Home</a>
        <a href="/stats" class="text-slate-500 font-semibold hover:text-emerald-500 transition-colors">Stats</a>
      </nav>
    </header>

    <main>
      <slot />
    </main>

    <footer class="text-center mt-12 text-slate-400 text-sm">
      <p>Powered by SvelteKit & Gudgusguz</p>
    </footer>
  </div>
</div>